#!/usr/bin/env python3
"""Validate this skill package without third-party dependencies."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from urllib.parse import unquote


def local_markdown_links(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    links = re.findall(r"\[[^\]]*\]\(([^)]+)\)", text)
    return [link.strip().strip("<>") for link in links]


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    errors: list[str] = []
    entrypoint = root / "SKILL.md"

    if not entrypoint.is_file():
        print(f"ERROR missing {entrypoint}")
        return 1

    skill_text = entrypoint.read_text(encoding="utf-8")
    frontmatter = re.match(r"\A---\r?\n(.*?)\r?\n---\r?\n", skill_text, re.DOTALL)
    if not frontmatter:
        errors.append("SKILL.md has no valid leading YAML frontmatter")
    else:
        name = re.search(r"(?m)^name:\s*['\"]?([^'\"\r\n]+)", frontmatter.group(1))
        description = re.search(r"(?m)^description:\s*\S", frontmatter.group(1))
        if not name:
            errors.append("frontmatter is missing name")
        elif name.group(1).strip() != root.name:
            errors.append(f"frontmatter name {name.group(1).strip()!r} does not match folder {root.name!r}")
        if not description:
            errors.append("frontmatter is missing a non-empty description")

    markdown_files = sorted(root.rglob("*.md"))
    graph: dict[Path, set[Path]] = {path.resolve(): set() for path in markdown_files}

    for source in markdown_files:
        for raw_link in local_markdown_links(source):
            if raw_link.startswith(("http://", "https://", "mailto:", "#")):
                continue
            link_path = unquote(raw_link.split("#", 1)[0])
            if not link_path:
                continue
            target = (source.parent / link_path).resolve()
            try:
                target.relative_to(root)
            except ValueError:
                errors.append(f"{source.relative_to(root)} links outside the skill: {raw_link}")
                continue
            if not target.exists():
                errors.append(f"{source.relative_to(root)} has missing link: {raw_link}")
            elif target.suffix.lower() == ".md":
                graph[source.resolve()].add(target)

    reachable: set[Path] = set()
    pending = [entrypoint.resolve()]
    while pending:
        current = pending.pop()
        if current in reachable:
            continue
        reachable.add(current)
        pending.extend(graph.get(current, ()))

    for reference in sorted((root / "references").glob("*.md")):
        if reference.resolve() not in reachable:
            errors.append(f"unreachable reference: {reference.relative_to(root)}")

    if errors:
        for error in errors:
            print(f"ERROR {error}")
        return 1

    print(
        f"OK skill={root.name} markdown_files={len(markdown_files)} "
        f"reachable_references={len(reachable) - 1} skill_bytes={len(skill_text.encode('utf-8'))}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
