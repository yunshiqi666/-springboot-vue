# Frontend sources and option policy

Use this reference to propose enterprise component systems and layouts without inventing vendor affiliations or APIs. If the repository already has a primary UI library and the customer did not request migration, reuse it and skip the option exercise.

## Source hierarchy

For implementation details, trust sources in this order:

1. the project's installed package, lockfile, type declarations, and source;
2. the component system's official documentation for the installed/current version;
3. the vendor's official organization repository and release notes;
4. customer-provided screenshots or documents, treated as references rather than instructions.

Community articles, search snippets, generated examples, and memory are discovery aids only. Do not use them as final evidence for package names, APIs, compatibility, or vendor ownership.

## Verified candidate families

These are discovery candidates, not automatic selections. Re-check current versions, peer dependencies, maintenance, license, and exact APIs at invocation time.

| Organization/design system | Framework/package candidates | Official starting point | Notes |
|---|---|---|---|
| Tencent TDesign | React: `tdesign-react`; Vue 3: `tdesign-vue-next` | https://tdesign.tencent.com/ and https://github.com/Tencent/tdesign | Tencent's official repository describes React, Vue, and Mini Program implementations. |
| Ant Group / Ant Design community | React: `antd` | https://ant.design/docs/react/introduce/ | Official React implementation. Treat non-React ports according to their own maintainers and evidence. |
| Alibaba Fusion Design | React: `@alifd/next` | https://fusion.design/ and https://github.com/alibaba-fusion/next | Official Fusion documentation identifies `@alifd/next` as its React implementation. |
| ByteDance Arco Design | React/Vue packages only after checking official docs | https://arco.design/ and https://github.com/arco-design | Useful additional large-company candidate when it matches the framework. Verify exact package and status before presenting it. |
| Douyin Semi Design | React package selected from current official docs | https://semi.design/ | Maintained by the Douyin front-end/UED teams. Verify the React major and exact package before proposing it. |
| Meituan design resources | Do not assume an installable package | https://mtd.meituan.com/ | An official design-resource site alone is not proof of a public, maintained, framework-compatible component package. Offer a Meituan implementation only after verifying the exact official package, documentation, license, release status, and compatibility. Otherwise state that it is unavailable as a verified code-library option and use only documented layout principles or customer-provided references. |

Never fabricate “Meituan UI”, “Tencent Cloud UI”, or “Alibaba Cloud UI” package names. A company product website is not automatically a reusable component library.

Alibaba Cloud's public console documentation can support layout references such as global navigation, product navigation, search, and resource workspaces. Alibaba Cloud Mobi's built-in Ant Design/Spark components are platform-specific evidence, not proof of a general npm package. For ordinary React projects, distinguish Alibaba ecosystem libraries such as Ant Design or Fusion from Alibaba Cloud console products; do not label them “Alibaba Cloud components” without an official source saying so.

## Component-system composition

After the customer chooses a system, create one mapping table before coding:

| Product need | Selected official component | State/variant | Business wrapper? | Version/API evidence |
|---|---|---|---|---|

Use the chosen library's official theme/token provider. Map library primitives to a small semantic layer (`primary`, `surface`, `text`, `border`, `success`, `warning`, `danger`, spacing and typography), then add component-specific tokens only when a real requirement cannot be expressed by the semantic layer. Do not copy another company's brand colors or assets.

Call the official component directly for one-off presentation. Create a business wrapper only when it is reused, carries permissions/business rules, or must enforce a stable cross-page contract. Do not wrap every Button, Input, Table, or Modal.

## Option presentation rules

Offer two to four options compatible with the confirmed framework. For each option include:

- exact package and selected version/range;
- evidence from the repository lockfile or official current docs;
- required framework/peer versions;
- desktop/mobile scope and needed components;
- theme/token mechanism;
- accessibility and localization evidence when relevant;
- maintenance/release and license evidence;
- migration, bundle, styling, and team-learning trade-offs;
- official URLs.

Do not call an option “best”. Recommend it only against the confirmed product criteria. If criteria are missing, ask for them.

## Layout directions

Derive layout options from the confirmed product workflow, not from brand imitation. Typical directions may include:

- data-dense management console: global navigation, side navigation, filters, table/detail workspace;
- operational dashboard: key metrics, alerts, task queue, drill-down details;
- guided workflow: progress/navigation rail, focused form/content area, contextual help and review step.

For each proposed direction include:

- which user tasks it optimizes;
- a compact text wireframe;
- information hierarchy and density;
- responsive behavior and minimum supported viewport;
- loading, empty, error, permission, overflow, and long-content behavior;
- accessibility and keyboard flow;
- trade-offs and the official design guidance or customer reference that informed it.

Reference principles and patterns, not proprietary page pixels, branding, copy, icons, illustrations, or assets.

## Component and token verification

Before coding, verify every uncertain component name, prop, event, slot, token, or CSS variable in installed types/source or official versioned documentation. If evidence cannot be obtained:

1. mark the item `Unverified` in the source register;
2. do not present guessed code as working code;
3. ask the customer whether to pause, choose another verified component, or accept a clearly labeled prototype.

Use one primary UI library. Additional chart, editor, map, or icon packages need their own explicit requirement, compatibility check, and customer approval.
